package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class RegisterActivity extends AppCompatActivity {
    EditText loginLastname,loginFirstname,loginEmail,loginPassword;
    CheckBox isemployeeBox, isclientBox;
    Button gotoRegister,loginBtn;
    boolean valid = true;
    FirebaseAuth fAuth;
    FirebaseFirestore fStore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();

        loginLastname = findViewById(R.id.loginLastName);
        loginFirstname = findViewById(R.id.loginFirstName);
        loginEmail = findViewById(R.id.loginEmail);
        loginPassword = findViewById(R.id.loginPassword);
        loginBtn= findViewById(R.id.loginBtn);
        gotoRegister = findViewById(R.id.gotoRegister);
        isclientBox = findViewById(R.id.isclient);
        isemployeeBox = findViewById(R.id.isemployee);

        // check boxes logic
        isclientBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if(compoundButton.isChecked()){
                    isemployeeBox.setChecked(false);
                }
            }
        });

        isemployeeBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if(compoundButton.isChecked()){
                    isclientBox.setChecked(false);
                }
            }
        });

        gotoRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkField(loginLastname);
                checkField(loginFirstname);
                checkField(loginEmail);
                checkField(loginPassword);

                //checkBox validation
                if(!(isclientBox.isChecked() || isemployeeBox.isChecked())){
                    Toast.makeText(RegisterActivity.this, "Select The Account Type", Toast.LENGTH_SHORT).show();
                    return;

                }

                if (valid){
                    fAuth.createUserWithEmailAndPassword(loginEmail.getText().toString(),loginPassword.getText().toString()).addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                        @Override
                        public void onSuccess(AuthResult authResult) {
                            FirebaseUser user = fAuth.getCurrentUser();
                            Toast.makeText(RegisterActivity.this, "Account Created", Toast.LENGTH_SHORT).show();
                            DocumentReference dr = fStore.collection("Users").document(user.getUid());
                            Map<String,Object> userInfo= new HashMap<>();
                            userInfo.put("Lastname",loginLastname.getText().toString());
                            userInfo.put("Fisrtname",loginFirstname.getText().toString());
                            userInfo.put("Email",loginEmail.getText().toString());
                            if(isclientBox.isChecked()){
                                userInfo.put("isClient","1");
                            }
                            if(isemployeeBox.isChecked()){
                                userInfo.put("isEmployee","1");
                            }

                            dr.set(userInfo);
                            if(isclientBox.isChecked()){
                                startActivity(new Intent(getApplicationContext(), Client.class));
                                finish();
                            }
                            if(isemployeeBox.isChecked()){
                                startActivity(new Intent(getApplicationContext(), Employee.class));
                                finish();
                            }
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(RegisterActivity.this, "Failed to create account", Toast.LENGTH_SHORT).show();;
                        }
                    });
                }
            }
        });
        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), LoginActivity.class));

            }
        });

    }

    public boolean checkField(EditText textField){
        if(textField.getText().toString().isEmpty()){
            textField.setError("Error");
            valid = false;
        }else {
            valid = true;
        }

        return valid;
    }

}
