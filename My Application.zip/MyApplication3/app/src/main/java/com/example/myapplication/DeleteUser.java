package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.FirebaseFirestore;

public class DeleteUser extends AppCompatActivity {
    FirebaseAuth fAuth;
    EditText loginEmail;
    Button deleteUser;
    boolean valid = true;
    FirebaseFirestore fStore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_user);
        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();

        loginEmail = findViewById(R.id.loginEmail);
        deleteUser = findViewById(R.id.deleteUser);

        deleteUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkField(loginEmail);

                // Vérifier si l'adresse e-mail est associée à un compte
                if (valid) {
                    deleteUser(String.valueOf(loginEmail));
                }
            }
        });
    }

    private void deleteUser(String email) {
        email = String.valueOf(loginEmail);
        DatabaseReference dr = FirebaseDatabase.getInstance().getReference("Users").child(email);
        dr.removeValue();
        Toast.makeText(getApplicationContext(), "User Deleted", Toast.LENGTH_SHORT).show();
    }

    public boolean checkField(EditText textField) {
        if (textField.getText().toString().isEmpty()) {
            textField.setError("Error");
            valid = false;
        } else {
            valid = true;
        }

        return valid;
    }
}

